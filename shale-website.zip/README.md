# Shale Website

A dark-themed website inspired by shale rock textures.

## Features
- Dark UI
- Card layout
- Simple responsive structure

## How to Run
Open index.html in your browser.

## Author
Generated with ChatGPT
